from inventory.camera import Camera
from inventory.laptop import Laptop

class Inventory():
    def __init__(self):
        self.cameraList = []
        self.laptopList = []

    def addCamera(self, assetTag, description, opticalzoom):
        correct = True
        error_message = ""
        if len(assetTag) == 0 or len(description) == 0 or opticalzoom < 0:
            correct = False
            error_message = "Incorrect values."
        
        notExist = self.findCamera(assetTag) is None
        if not notExist:
            error_message = "Asset already exists."

        if correct and notExist:
            new_camera = Camera(assetTag, description, opticalzoom)
            self.cameraList.append(new_camera)
            return True
        else:
            print(error_message)
            return False

    def findCamera(self, assetTag):
        for c in self.cameraList:
            if c.getAssetTag() == assetTag:
                return c
        return None

    def addLaptop(self, assetTag, description, os):
        correct = True
        error_message = ""
        if len(assetTag) == 0 or len(description) == 0 or len(os) == 0:
            correct = False
            error_message = "Incorrect values."
        
        notExist = self.findLaptop(assetTag) is None
        if not notExist:
            error_message = "Asset already exists."

        if correct and notExist:
            new_laptop = Laptop(assetTag, description, os)
            self.laptopList.append(new_laptop)
            return True
        else:
            print(error_message)
            return False

    def findLaptop(self, assetTag):
        for l in self.laptopList:
            if l.getAssetTag() == assetTag:
                return l
        return None

# Make sure you have the Camera and Laptop classes defined in their respective modules