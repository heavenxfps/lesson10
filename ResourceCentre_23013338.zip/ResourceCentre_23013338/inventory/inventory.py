from inventory.camera import Camera

class Inventory():
    pass

def __init__(self):
    self.cameraList = []

def addCamera(self, assetTag, description, opticalzoom):
    new_camera = Camera(assetTag, description, opticalzoom)
    self.cameraList.append(new_camera)
    
    return True 